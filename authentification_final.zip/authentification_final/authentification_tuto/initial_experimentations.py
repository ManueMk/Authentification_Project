import cv2
import os
import face_recognition
from matplotlib.pyplot import imsave

# Charger le classificateur Haar Cascade pour la détection de visages
def load_known_faces():
    known_encodings = []
    known_names = []

    # Chemin vers le répertoire contenant les images d'entraînement
    training_images_dir = '/home/manuemk/Documents/M2/VISION_PO/authentification_projet (1)/authentification_final/authentification_tuto/site_authentification/media'  # Assurez-vous que c'est le chemin correct

    # Parcourir chaque sous-répertoire dans le répertoire des images d'entraînement
    for person_dir in os.listdir(training_images_dir):
        person_name = person_dir  # Utilisez le nom du répertoire comme nom de la personne
        for image_file in os.listdir(os.path.join(training_images_dir, person_dir)):
            image_path = os.path.join(training_images_dir, person_dir, image_file)
            
            # Vérifier si c'est bien un fichier (et non un répertoire)
            if os.path.isfile(image_path):
                # Charger l'image et calculer l'encodage facial
                image = face_recognition.load_image_file(image_path)
                encoding = face_recognition.face_encodings(image)[0]  # Prendre le premier visage trouvé
                known_encodings.append(encoding)
                known_names.append(person_name)

    return known_encodings, known_names
# Chargement des visages connus au démarrage du serveur
known_encodings, known_names = load_known_faces()


# Initialisation du classificateur de détection de visages Haar Cascade
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

def generate_frames(image_path):
    image = cv2.imread(image_path)
    # Convertir l'image en niveaux de gris pour la détection de visages avec Haar Cascade
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Détection de visages avec Haar Cascade
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
    
    # Parcourir chaque visage détecté
    for (x, y, w, h) in faces:
        # Récupérer la région du visage
        face_image = image[y:y+h, x:x+w]
        # Redimensionner l'image du visage pour la reconnaissance faciale
        small_face_image = cv2.resize(face_image, (0, 0), fx=0.25, fy=0.25)
        
        # Obtenir les encodages du visage avec face_recognition
        face_encodings = face_recognition.face_encodings(small_face_image)
        
        # Comparaison des encodages avec les visages connus
        for face_encoding in face_encodings:
            matches = face_recognition.compare_faces(known_encodings, face_encoding)
            name = "Inconnu"
            
            # Trouver la correspondance
            if True in matches:
                match_index = matches.index(True)
                name = known_names[match_index]
                
                    
            # Dessiner un rectangle autour du visage et afficher le nom
            cv2.rectangle(image, (x, y), (x+w, y+h), (0, 255, 0), 2)
            cv2.putText(image, name, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
            
            
    # Conversion de l'image en format JPEG pour le streaming
    #ret, buffer = cv2.imencode('.jpg', image)
    #image = buffer.tobytes()

    imsave("/home/manuemk/Documents/M2/VISION_PO/authentification_projet (1)/authentification_final/authentification_tuto/site_authentification/media/alane_gmail_com/fils22.jpeg", image)

generate_frames("/home/manuemk/Documents/M2/VISION_PO/authentification_projet (1)/authentification_final/authentification_tuto/site_authentification/media/alane_gmail_com/fils.jpeg")